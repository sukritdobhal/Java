set serveroutput on

DECLARE
   v_rows NUMBER := 0;
BEGIN
   FOR i IN (
      SELECT
         sap_cust_number,
         sap_sales_org,
         fa_kto_nr
      FROM
         dbxnet.newsapcust_kto_map
   ) LOOP
      UPDATE dbxnet.dfst_d
      SET
         sap_cust_number = i.sap_cust_number,
         sales_org = i.sap_sales_org
         
      WHERE
         fa_kto_nr = i.fa_kto_nr;

      v_rows := v_rows + SQL%rowcount;
   END LOOP;

   dbms_output.put_line(v_rows);
END;
---------------------------------------------------------------------------------------------------
---0626
ALTER TABLE DBXNET.DFOR_D MODIFY FA_KTO_NR NULL;
----------------------------------------------------------------------------------------------------------
---0628
  -- CREATE UNIQUE INDEX "DBXNET"."MTD_DFCC_UKEY" ON "DBXNET"."DFCC_D" ("FA_KTO_NR", "YEAR_ID", "VKWG", "CONDGROUP", "KATEGORIE") 
  -- PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  -- STORAGE(INITIAL 2097152 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  -- PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1
  -- BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  -- TABLESPACE "ORDAT_TABLESPACE" ;
  
 ALTER INDEX "DBXNET"."MTD_DFCC_UKEY" unusable;
 --------------------------------------------------------------------------------------------------------------------------
 
 