-- Table 1 – Storing Payment terms –
-- Sap Sales Org – (take reference from Customer master for this – to know the type of field and char limit)
-- Customer Hier code  – (take reference from Customer master for this – to know the type of field and char limit)
-- Start date
-- End date
-- Payment code (FK to the second table)
-- Sequence number
 
-- Table 2 – Payment term master data –
-- Payment code (PK)
-- Payment description


---------------------------------------------------------------------------------------------------------------------------------------------

 CREATE TABLE "DBXNET"."PAYMENT_TERMS" 
   (	"SAP_SALES_ORG" VARCHAR2(100),
	CUST_GROUP VARCHAR2(200),
	"START_DATE" DATE,
	"END_DATE" DATE,
	"PAYMENT_CODE" VARCHAR2(100),
	ORDAT_SEQUENCE NUMBER(9,0)
   );
   
 -------------------------------------------------------------------------------------------------------------------------------------------
CREATE SEQUENCE DBXNET.PAYMENT_TERMS_SEQ INCREMENT BY 1 MINVALUE 1 MAXVALUE 999999999999999999999999999 NOCYCLE CACHE 20 NOORDER ;

------------------------------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE EDITIONABLE TRIGGER "DBXNET"."PAYMENT_TERMS_TRIGG" 
                BEFORE INSERT ON DBXNET.PAYMENT_TERMS
                FOR EACH ROW
                BEGIN
                        SELECT
                                PAYMENT_TERMS_SEQ.NEXTVAL
                        INTO
                                :NEW.ORDAT_SEQUENCE
                        FROM
                                DUAL;
                END;

ALTER TRIGGER "DBXNET"."PAYMENT_TERMS_TRIGG" ENABLE;
---------------------------------------------------------------------------------------------------------------------------------------------------
 CREATE TABLE "DBXNET"."PAYMENT_TERMS_MASTER" 
   (	
	"PAYMENT_CODE" VARCHAR2(100),
	"PAYMENT_DESCRIPTION" VARCHAR2(4000)
   );
------------------------------------------------------------------------------------------------------------------------------------------------
ALTER TABLE "DBXNET"."PAYMENT_TERMS_MASTER" ADD CONSTRAINT "PT_TERMS" FOREIGN KEY ("PAYMENT_CODE")
	  REFERENCES "DBXNET"."PAYMENT_TERMS" ("PAYMENT_CODE") ENABLE;
-------------------------------------------------------------------------------------------------------------------------------------------