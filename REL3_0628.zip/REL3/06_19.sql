--SELECT * FROM DBXNET.DFCK_D;
--------------------------------------------------------------------------------------------------------------------------------
ALTER TABLE DBXNET.DFCK_D ADD SAP_CUST_NUMBER VARCHAR2(200);

-- DBXNET.DFCK_DV source
------------------------------------------------------------------------------------------------------------------------------
CREATE OR REPLACE FORCE EDITIONABLE VIEW "DBXNET"."DFCK_DV" ("CL_ID", "FA_KTO_NR", "CHECK_OK", "LETZT_AEND", "BENUTZERX12", "ORDAT_SEQUENCE", "SAP_CUST_NUMBER") AS 
  SELECT
CL_ID,
FA_KTO_NR,
CHECK_OK,
LETZT_AEND,
BENUTZERX12,
ORDAT_SEQUENCE,
SAP_CUST_NUMBER
FROM DFCK_D;
-------------------------------------------------------------------------------------------------------------------------------
set serveroutput on

DECLARE
   v_rows NUMBER := 0;
BEGIN
   FOR i IN (
      SELECT
         sap_cust_number,
         fa_kto_nr
      FROM
         dbxnet.newsapcust_kto_map
   ) LOOP
      UPDATE dbxnet.dfck_d
      SET
         sap_cust_number = i.sap_cust_number
      WHERE
         fa_kto_nr = i.fa_kto_nr;

      v_rows := v_rows + SQL%rowcount;
   END LOOP;

   dbms_output.put_line(v_rows);
END;
--------------------------------------------------------------------------------------------------------------------------------
ALTER TABLE DBXNET.DFST_D MODIFY FA_KTO_NR NULL;
------------------------------------------------------------------------------------------------------------------------------------
ALTER TABLE dbxnet.dfst_d MODIFY
   fa_kto_nr null;

DROP INDEX "DBXNET"."MTD_FA_KTO_NR_YEAR";

CREATE INDEX "DBXNET"."MTD_SAPCUT_YEAR" ON
   "DBXNET"."DFST_D" (
      "SAP_CUST_NUMBER",
      "YEAR_ID"
   );

ALTER TABLE "DBXNET"."DFST_D"
   ADD CONSTRAINT uk_id UNIQUE ( "SAP_CUST_NUMBER",
                                 "YEAR_ID" ) ENABLE NOVALIDATE;
------------------------------------------------------------------------------------								 --------------